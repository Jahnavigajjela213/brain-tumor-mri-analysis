# 🧠 NeuroGuard AI: Clinical Brain Tumor Intelligence

[![Tech Stack](https://img.shields.io/badge/Stack-FastAPI%20%7C%20PyTorch%20%7C%20React-blue)](https://github.com/your-repo)
[![Precision](https://img.shields.io/badge/Model-Attention%20U--Net-red)](https://github.com/your-repo)
[![Dataset](https://img.shields.io/badge/Dataset-BraTS%202020-green)](https://www.med.upenn.edu/cbica/brats2020/)

**NeuroGuard AI** is a state-of-the-art clinical research workstation designed for the automated segmentation of brain tumors and the prediction of patient survival metrics. By leveraging multi-modal MRI simulation and attention-gated neural networks, it provides high-precision visualizations of tumor subregions following international neuro-oncology standards.

---

## 🛠 Clinical Core Features

### 1. Multi-Modal Tissue Characterization
The system simulates four critical MRI sequences from a single anatomical upload to detect varying tissue properties:
- **T1 / T1ce**: Identification of the enhancing tumor margin.
- **T2 / FLAIR**: Detection of peritumoral edema and the whole tumor extent.

### 2. Multi-Class Subregion Segmentation
Utilizing an **Attention U-Net**, the system delineates three nested clinical regions:
- 🟢 **Whole Tumor (WT)**: The entire visible tumor mass.
- 🟡 **Tumor Core (TC)**: The gross tumor volume excluding edema.
- 🔴 **Enhancing Tumor (ET)**: The active, high-grade region of the tumor.

### 3. Survival Analysis Engine
A **DenseNet-integrated CNN** evaluates the spatial distribution and volumetric features of the segmented tumor to provide:
- **Survival Probability**: Risk-stratified projection.
- **Estimated Lifespan**: Data-driven prediction in days.

---

## 🏗 System Architecture

```mermaid
graph TD
    A[MRI Upload] --> B[Preprocessing & Augmentation]
    B --> C[Multi-modal Simulation]
    C --> D[Attention U-Net]
    D --> E[Subregion Masks]
    E --> F[Overlap Generation]
    E --> G[DenseNet Survival Engine]
    F --> H[Clinical Dashboard]
    G --> H
```

---

## 📡 Deployment Guide

### ☁️ Backend: Render (FastAPI + PyTorch)
1. **Repository**: Push your code to GitHub.
2. **New Service**: Select "Web Service" on [Render](https://render.com).
3. **Configuration**:
   - **Environment**: `Python`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn -w 4 -k uvicorn.workers.UvicornWorker app.app:app`
4. **Environment Variables**:
   - `PORT`: `8000`
   - `PYTHONPATH`: `.`

### 📐 Frontend: Vercel (React + Vite)
1. **New Project**: Import your repository into [Vercel](https://vercel.com).
2. **Framework Preset**: Select `Vite`.
3. **Environment Variables**:
   - `VITE_API_URL`: Your Render Web Service URL (e.g., `https://neuroguard-api.onrender.com`).
4. **Deploy**: Vercel will automatically build and serve your frontend.

---

## 🛠 Local Development

```bash
# Backend Setup
cd backend
pip install -r requirements.txt
uvicorn app.app:app --host 0.0.0.0 --port 8001

# Frontend Setup
cd frontend
npm install
npm run dev
```

---

## ⚠️ Medical Disclaimer
**FOR RESEARCH DEMONSTRATION ONLY.** This software is not a diagnostic tool and is not intended for clinical use. All predictions should be verified by a board-certified radiologist or neuro-oncologist.

---
**Developed by Antigravity AI** | Senior Engineering Finalization v2.1
